/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8014351446099912, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.7564102564102564, 500, 1500, "authors POST"], "isController": false}, {"data": [0.8977272727272727, 500, 1500, "activities DELETE "], "isController": false}, {"data": [0.932258064516129, 500, 1500, "users DELETE"], "isController": false}, {"data": [0.7919161676646707, 500, 1500, "coverPhotos all GET"], "isController": false}, {"data": [0.8586626139817629, 500, 1500, "coverPhotosCoverPhotosForBook  GET"], "isController": false}, {"data": [0.8333333333333334, 500, 1500, "authors all GET"], "isController": false}, {"data": [0.7220630372492837, 500, 1500, "authors DELETE"], "isController": false}, {"data": [0.9158878504672897, 500, 1500, "users all GET"], "isController": false}, {"data": [0.6544117647058824, 500, 1500, "books PUT"], "isController": false}, {"data": [0.7011834319526628, 500, 1500, "books POST"], "isController": false}, {"data": [0.8977591036414566, 500, 1500, "activities GET"], "isController": false}, {"data": [0.8629943502824858, 500, 1500, "activities PUT "], "isController": false}, {"data": [0.7191977077363897, 500, 1500, "authors PUT"], "isController": false}, {"data": [0.5260869565217391, 500, 1500, "books GET"], "isController": false}, {"data": [0.8023952095808383, 500, 1500, "books DELETE"], "isController": false}, {"data": [0.8544891640866873, 500, 1500, "coverPhotos POST"], "isController": false}, {"data": [0.9009584664536742, 500, 1500, "users PUT"], "isController": false}, {"data": [0.8765822784810127, 500, 1500, "users POST"], "isController": false}, {"data": [0.915954415954416, 500, 1500, "authors GET"], "isController": false}, {"data": [0.9305993690851735, 500, 1500, "users GET"], "isController": false}, {"data": [0.8834269662921348, 500, 1500, "activities POST"], "isController": false}, {"data": [0.8554216867469879, 500, 1500, "coverPhotos GET"], "isController": false}, {"data": [0.27363896848137537, 500, 1500, "books all GET"], "isController": false}, {"data": [0.9065420560747663, 500, 1500, "coverPhotos DELETE"], "isController": false}, {"data": [0.8358895705521472, 500, 1500, "coverPhotos PUT"], "isController": false}, {"data": [0.7005571030640668, 500, 1500, "activities all GET"], "isController": false}, {"data": [0.8917378917378918, 500, 1500, "authorsAuthorsForBook GET "], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 9128, 0, 0.0, 657.0877519719508, 72, 27710, 1134.1000000000004, 1548.0999999999985, 3402.709999999999, 75.5372762555755, 2801.1108654011264, 16.675458673484165], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["authors POST", 351, 0, 0.0, 611.3162393162394, 82, 2980, 1398.600000000001, 2059.6, 2651.9600000000005, 3.855956409017006, 1.190675018950213, 1.066410798737751], "isController": false}, {"data": ["activities DELETE ", 352, 0, 0.0, 347.7869318181819, 73, 2974, 746.5999999999999, 931.9499999999994, 1771.1799999999944, 3.8490978676872607, 0.7931246582832149, 0.7521506800164024], "isController": false}, {"data": ["users DELETE", 310, 0, 0.0, 260.49354838709684, 74, 1346, 539.8000000000001, 795.4999999999999, 1145.3799999999994, 3.9290738792633615, 0.8096040903560248, 0.7485836322386848], "isController": false}, {"data": ["coverPhotos all GET", 334, 0, 0.0, 503.5958083832336, 82, 2280, 916.0, 1229.75, 1804.899999999998, 3.937147100774463, 79.73876340132968, 0.6805420281612109], "isController": false}, {"data": ["coverPhotosCoverPhotosForBook  GET", 329, 0, 0.0, 397.59878419452895, 82, 2289, 775.0, 918.0, 1543.1999999999998, 4.003455870721231, 1.4011667746626266, 0.6884742452451356], "isController": false}, {"data": ["authors all GET", 351, 0, 0.0, 482.41025641025635, 153, 2937, 904.2, 1118.7999999999993, 1967.0400000000004, 3.863596336738288, 181.36029110781195, 0.6527364904841053], "isController": false}, {"data": ["authors DELETE", 349, 0, 0.0, 632.2521489971347, 72, 3494, 1418.0, 1817.5, 2881.5, 3.8888393653057585, 0.8013135801557765, 0.7485267120921733], "isController": false}, {"data": ["users all GET", 321, 0, 0.0, 301.08411214953264, 77, 1524, 620.6, 836.9, 1159.8399999999992, 4.00539043198323, 3.0666270494871606, 0.6688689100284495], "isController": false}, {"data": ["books PUT", 340, 0, 0.0, 776.6911764705883, 80, 3809, 1578.5000000000002, 2140.899999999999, 3375.0299999999947, 3.8516001132823563, 1.5161914117813649, 1.4187730104786178], "isController": false}, {"data": ["books POST", 338, 0, 0.0, 671.9142011834323, 80, 3403, 1290.8000000000002, 1580.9500000000005, 3193.2200000000003, 3.854267632134101, 1.5172659858030675, 1.4382233878784425], "isController": false}, {"data": ["activities GET", 357, 0, 0.0, 310.76470588235327, 72, 1244, 727.5999999999999, 835.0, 1100.1800000000012, 3.841601205208221, 1.3191002300118368, 0.6681461348595716], "isController": false}, {"data": ["activities PUT ", 354, 0, 0.0, 390.0734463276836, 75, 2301, 914.5, 1188.5, 2086.899999999998, 3.8512587306077157, 1.302387896005135, 1.1598419413227006], "isController": false}, {"data": ["authors PUT", 349, 0, 0.0, 696.8280802292267, 73, 4682, 1331.0, 2146.5, 3275.0, 3.8966984134073224, 1.2032273197358283, 1.0590049043689915], "isController": false}, {"data": ["books GET", 345, 0, 0.0, 998.7884057971016, 166, 5531, 1923.2000000000005, 2525.0999999999995, 4009.9400000000064, 3.864117469171063, 18.241493603905557, 0.6532073575036681], "isController": false}, {"data": ["books DELETE", 334, 0, 0.0, 510.0419161676645, 77, 2515, 1088.0, 1457.0, 2183.0999999999995, 3.9257169722614007, 0.8089123839327692, 0.7479633139398214], "isController": false}, {"data": ["coverPhotos POST", 323, 0, 0.0, 420.3653250773994, 84, 2640, 827.6000000000013, 1041.8000000000002, 1834.7599999999993, 3.9936694774846067, 1.2062801186663865, 1.0580775404003562], "isController": false}, {"data": ["users PUT", 313, 0, 0.0, 311.2939297124601, 73, 1641, 681.6000000000003, 944.6, 1202.16, 3.9331984568793277, 1.1987768247590447, 1.0339936376116816], "isController": false}, {"data": ["users POST", 316, 0, 0.0, 364.77215189873414, 74, 1661, 779.0, 989.15, 1448.9199999999996, 3.9706972594649614, 1.2102022220511919, 1.0473415922684493], "isController": false}, {"data": ["authors GET", 351, 0, 0.0, 323.76638176638147, 73, 2249, 597.0, 746.3999999999997, 1265.88, 3.8866558150350468, 1.2536709900176062, 0.6646018807649293], "isController": false}, {"data": ["users GET", 317, 0, 0.0, 284.5425867507884, 74, 1591, 576.7999999999996, 808.0999999999997, 1412.239999999999, 3.9800120530333465, 1.2060267324666032, 0.6727844704198473], "isController": false}, {"data": ["activities POST", 356, 0, 0.0, 365.81741573033696, 75, 2272, 814.4000000000001, 1046.449999999997, 1553.3500000000004, 3.8603339839514206, 1.3055460956137497, 1.15852165677185], "isController": false}, {"data": ["coverPhotos GET", 332, 0, 0.0, 406.171686746988, 78, 2676, 793.6999999999998, 1043.1, 1930.6800000000128, 4.010146152917019, 1.39570940028989, 0.7013816017936948], "isController": false}, {"data": ["books all GET", 349, 0, 0.0, 1671.0429799426934, 464, 5649, 2833.0, 3621.5, 5167.0, 3.8465777581836216, 3417.9024367457014, 0.642348434227929], "isController": false}, {"data": ["coverPhotos DELETE", 321, 0, 0.0, 326.42056074766344, 75, 2315, 643.6, 834.0, 1444.0, 4.033220671198282, 0.8310640250223021, 0.7920697466044303], "isController": false}, {"data": ["coverPhotos PUT", 326, 0, 0.0, 443.34969325153384, 81, 2189, 870.1000000000001, 1066.0, 1914.4400000000023, 4.008459571119418, 1.210736731199587, 1.050626014410781], "isController": false}, {"data": ["activities all GET", 359, 0, 0.0, 4245.470752089138, 291, 27710, 27208.0, 27533.0, 27692.8, 2.9846279191573206, 9.053932639587472, 0.5129829236051645], "isController": false}, {"data": ["authorsAuthorsForBook GET ", 351, 0, 0.0, 347.96581196581207, 75, 2100, 745.0, 998.8, 1724.48, 3.8845911218831968, 1.7913102678818464, 0.6718359189105437], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 9128, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
